from setuptools import find_packages, setup

package_name = 'drone_project'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
    ('share/ament_index/resource_index/packages',
        ['resource/drone_project']),
    ('share/' + package_name, ['package.xml']),
    ('share/' + package_name + '/launch', ['launch/drone_launch.py']),
],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='mohammed-hany',
    maintainer_email='mohammed-hany@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [
        'talker_node = drone_project.talker_node:main',
        'listener_node = drone_project.listener_node:main',
        'planning_node = drone_project.planning_node:main',
        'outer_pid_node = drone_project.outer_pid_node:main',
        'dummy_localization_node = drone_project.dummy_localization_node:main',
        'trajectory_plotter_node = drone_project.trajectory_plotter_node:main',
    ],
},
)

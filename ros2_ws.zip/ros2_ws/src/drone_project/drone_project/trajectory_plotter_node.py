#!/usr/bin/env python3
"""
Trajectory plotter node.

Subscribes to /localization/current_position and displays the drone's
position history as a live-updating 3D plot.

matplotlib's GUI event loop must run on the main thread, so this node spins
rclpy on a background thread while matplotlib's FuncAnimation drives the
plot on the main thread. The two only communicate through a lock-protected
position history buffer.
"""
import threading
from collections import deque

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401  (registers the '3d' projection)
from matplotlib.animation import FuncAnimation


class TrajectoryPlotterNode(Node):
    def __init__(self):
        super().__init__('trajectory_plotter_node')

        self.declare_parameter('history_length', 500)  # number of points kept in the trail
        history_length = self.get_parameter('history_length').value

        self._lock = threading.Lock()
        self.xs = deque(maxlen=history_length)
        self.ys = deque(maxlen=history_length)
        self.zs = deque(maxlen=history_length)

        self.create_subscription(
            PoseStamped, '/localization/current_position',
            self.position_callback, 10)

        self.get_logger().info('Trajectory plotter node started.')

    def position_callback(self, msg: PoseStamped):
        with self._lock:
            self.xs.append(msg.pose.position.x)
            self.ys.append(msg.pose.position.y)
            self.zs.append(msg.pose.position.z)

    def get_history(self):
        with self._lock:
            return list(self.xs), list(self.ys), list(self.zs)


def spin_node(node):
    try:
        rclpy.spin(node)
    except Exception:
        # Node is being shut down from the main thread; nothing else to do here.
        pass


def main(args=None):
    rclpy.init(args=args)
    node = TrajectoryPlotterNode()

    spin_thread = threading.Thread(target=spin_node, args=(node,), daemon=True)
    spin_thread.start()

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlabel('X [m]')
    ax.set_ylabel('Y [m]')
    ax.set_zlabel('Z [m]')
    ax.set_title('Drone Current Position (live)')

    trail_line, = ax.plot([], [], [], color='tab:blue', linewidth=1.0, label='trajectory')
    current_point, = ax.plot(
        [], [], [], color='tab:red', marker='o', markersize=8, linestyle='',
        label='current position')
    ax.legend(loc='upper right')

    def update(frame):
        xs, ys, zs = node.get_history()
        if not xs:
            return trail_line, current_point

        trail_line.set_data(xs, ys)
        trail_line.set_3d_properties(zs)

        current_point.set_data([xs[-1]], [ys[-1]])
        current_point.set_3d_properties([zs[-1]])

        # Auto-scale axes with a fixed margin so the trail doesn't get clipped.
        margin = 0.5
        ax.set_xlim(min(xs) - margin, max(xs) + margin)
        ax.set_ylim(min(ys) - margin, max(ys) + margin)
        ax.set_zlim(min(zs) - margin, max(zs) + margin)

        return trail_line, current_point

    # blit=False because 3D axes don't support blitting reliably.
    ani = FuncAnimation(fig, update, interval=100, blit=False)  # noqa: F841

    try:
        plt.show()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
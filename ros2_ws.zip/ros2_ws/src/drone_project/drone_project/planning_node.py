#!/usr/bin/env python3
"""
Planning node.

Stores a trajectory as a list of (x, y, z) waypoints and publishes the
currently active waypoint as the desired position. Desired yaw is always 0.
Advances to the next waypoint once the drone's current position (from the
localization node) comes within `waypoint_radius` meters of the target.
"""
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped


class PlanningNode(Node):
    def __init__(self):
        super().__init__('planning_node')

        # ---- Parameters ----

        self.waypoint_radius = 0.3
        self.loop_waypoints = True
        publish_rate = 20                                 # [Hz]

        # ---- Trajectory definition (x, y, z) in meters ----
        # Replace this with whatever path you need; could also be loaded
        # from a yaml param, a csv file, or generated on the fly.
        self.waypoints = [
            (0.0, 0.0, 0.5),
            (0.0, 0.0, 1.0),
            (0.0, 0.0, 1.5),
            (0.0, 0.0, 2.0),
            (0.0, 0.0, 2.5),
            (0.0, 0.0, 3.0),
            (0.0, 0.0, 2.5),
            (0.0, 0.0, 2.0),
            (0.0, 0.0, 1.5),
            (0.0, 0.0, 1.0),
        ]
        self.current_index = 0
        self.current_position = None

        self.desired_pub = self.create_publisher(
            PoseStamped, '/planning/desired_position', 10)
        self.create_subscription(
            PoseStamped, '/localization/current_position',
            self.position_callback, 10)

        self.timer = self.create_timer(1.0 / publish_rate, self.timer_callback)

        self.get_logger().info(
            f'Planning node started with {len(self.waypoints)} waypoints, '
            f'radius={self.waypoint_radius} m.')

    def position_callback(self, msg: PoseStamped):
        self.current_position = msg

    def distance_to_target(self):
        if self.current_position is None:
            return None
        tx, ty, tz = self.waypoints[self.current_index]
        dx = self.current_position.pose.position.x - tx
        dy = self.current_position.pose.position.y - ty
        dz = self.current_position.pose.position.z - tz
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def timer_callback(self):
        dist = self.distance_to_target()

        if dist is not None and dist < self.waypoint_radius:
            if self.current_index < len(self.waypoints) - 1:
                self.current_index += 1
                self.get_logger().info(
                    f'Reached waypoint {self.current_index - 1}, '
                    f'switching to waypoint {self.current_index}: '
                    f'{self.waypoints[self.current_index]}')
            elif self.loop_waypoints:
                self.current_index = 0
                self.get_logger().info('Trajectory complete, restarting loop.')

        x, y, z = self.waypoints[self.current_index]
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'world'
        msg.pose.position.x = x
        msg.pose.position.y = y
        msg.pose.position.z = z
        # Desired yaw is always 0 -> identity orientation quaternion
        msg.pose.orientation.w = 1.0
        self.desired_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = PlanningNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
#!/usr/bin/env python3
"""
Outer loop PID controller.

Subscribes to the desired position (from the planning node) and the current
position (from the localization node). Runs PID loops on the x and y
position errors to produce a *desired horizontal acceleration* (m/s^2), and
a separate PID on the z error to produce a climb-rate/thrust-equivalent
command.

The desired acceleration is then converted into desired roll/pitch angles
through the quadrotor's actual thrust-tilt relationship:

    a_x = g * tan(pitch)
    a_y = -g * tan(roll)

so, given a desired yaw (fixed at 0 here, but kept general), the desired
world-frame acceleration is first rotated into the heading frame and then
inverted with atan2:

    pitch_des = atan2(a_x_body,  g)
    roll_des  = atan2(-a_y_body, g)

This keeps the PID's job limited to "how much acceleration do I need" and
keeps the physics (gravity, tilt geometry, yaw rotation) in an explicit,
separate conversion step rather than baked into arbitrary PID gains. This
node only implements the *outer* (position) loop -- it assumes an inner
attitude controller (not implemented here) can track the commanded
roll/pitch essentially instantaneously.
"""
import math
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Vector3Stamped
from std_msgs.msg import Float64


class PID:
    def __init__(self, kp, ki, kd, out_min, out_max, integral_limit=None):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.out_min = out_min
        self.out_max = out_max
        self.integral_limit = integral_limit if integral_limit is not None else out_max

        self.integral = 0.0
        self.prev_error = 0.0
        self.prev_time = None

    def update(self, error, now):
        dt = 0.0 if self.prev_time is None else (now - self.prev_time)
        self.prev_time = now

        if dt > 0.0:
            self.integral += error * dt
            self.integral = max(-self.integral_limit, min(self.integral_limit, self.integral))
            derivative = (error - self.prev_error) / dt
        else:
            derivative = 0.0

        self.prev_error = error

        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        return max(self.out_min, min(self.out_max, output))

    def reset(self):
        self.integral = 0.0
        self.prev_error = 0.0
        self.prev_time = None


def accel_to_attitude(ax_des, ay_des, az_des, yaw_des, gravity):
    """
    Convert a desired world-frame horizontal acceleration into desired
    roll/pitch angles for a given desired yaw, by inverting the quadrotor's
    thrust-tilt relationship (a = g * tan(angle)).

    ax_des, ay_des : desired world-frame accelerations [m/s^2]
    yaw_des        : desired yaw [rad] (fixed at 0 in this project, but the
                      rotation is kept here so the node stays correct if
                      that ever changes)
    gravity        : g [m/s^2]

    Returns (roll_des, pitch_des) in radians.
    """
    cos_yaw = math.cos(yaw_des)
    sin_yaw = math.sin(yaw_des)

    # Rotate world-frame desired acceleration into the heading (body-yaw) frame.
    ax_body = ax_des * cos_yaw + ay_des * sin_yaw
    ay_body = -ax_des * sin_yaw + ay_des * cos_yaw

    pitch_des = math.atan2(ax_body, az_des+gravity)
    roll_des = math.atan2(-ay_body*math.cos(pitch_des), az_des+gravity)
    return roll_des, pitch_des


class OuterPIDNode(Node):
    def __init__(self):
        super().__init__('outer_pid_node')

        # ---- Parameters ----    
        self.mass=1.5
        self.max_tilt = math.radians(15)
        max_climb = 1
        self.gravity = 9.81
        kp_xy = 1.2
        ki_xy = 0.05
        kd_xy = 0.8
        kp_z = 2.0
        ki_z = 0.1
        kd_z = 1.0

        # Max horizontal acceleration achievable at max tilt: a = g * tan(theta_max).
        # PID acceleration outputs are limited to this so that, even before the
        # vector-magnitude saturation below, no single axis can imply a tilt
        # beyond max_tilt.
        max_accel_xy = self.gravity * math.tan(self.max_tilt)

        self.pid_x = PID(kp_xy, ki_xy, kd_xy, -max_accel_xy, max_accel_xy)
        self.pid_y = PID(kp_xy, ki_xy, kd_xy, -max_accel_xy, max_accel_xy)
        self.pid_z = PID(kp_z, ki_z, kd_z, -max_climb, max_climb)
        self.max_accel_xy = max_accel_xy

        # Desired yaw is fixed at 0 for this project, but kept as an explicit
        # value (rather than hardcoded inline) so the acceleration->attitude
        # conversion stays correct if a real yaw reference is added later.
        self.yaw_des = 0.0

        self.desired_position = None
        self.current_position = None

        self.attitude_pub = self.create_publisher(
            Vector3Stamped, '/control/desired_attitude', 10)
        self.thrust_pub = self.create_publisher(
            Float64, '/control/desired_thrust', 10)

        self.create_subscription(
            PoseStamped, '/planning/desired_position', self.desired_cb, 10)
        self.create_subscription(
            PoseStamped, '/localization/current_position', self.current_cb, 10)

        control_rate = 50   # [Hz]
        self.timer = self.create_timer(1.0 / control_rate, self.control_loop)

        self.get_logger().info('Outer loop PID controller node started.')

    def desired_cb(self, msg: PoseStamped):
        self.desired_position = msg

    def current_cb(self, msg: PoseStamped):
        self.current_position = msg

    def control_loop(self):
        if self.desired_position is None or self.current_position is None:
            return

        now = time.monotonic()

        ex = self.desired_position.pose.position.x - self.current_position.pose.position.x
        ey = self.desired_position.pose.position.y - self.current_position.pose.position.y
        ez = self.desired_position.pose.position.z - self.current_position.pose.position.z

        # Position error -> desired world-frame horizontal acceleration [m/s^2].
        ax_des = self.pid_x.update(ex, now)
        ay_des = self.pid_y.update(ey, now)
        az_des = self.pid_z.update(ez, now)

        # Saturate the *combined* acceleration vector (not just each axis
        # independently) so that large errors on both axes at once still
        # can't imply a tilt beyond max_tilt.
        accel_mag = math.hypot(ax_des, ay_des)
        if accel_mag > self.max_accel_xy and accel_mag > 0.0:
            scale = self.max_accel_xy / accel_mag
            ax_des *= scale
            ay_des *= scale

        # Convert desired acceleration -> desired roll/pitch via the actual
        # thrust-tilt relationship, rather than treating PID output as an
        # angle directly.
        roll_cmd, pitch_cmd = accel_to_attitude(
            ax_des, ay_des, az_des, self.yaw_des, self.gravity)

        # Belt-and-suspenders clamp in case of any residual numerical edge case.
        roll_cmd = max(-self.max_tilt, min(self.max_tilt, roll_cmd))
        pitch_cmd = max(-self.max_tilt, min(self.max_tilt, pitch_cmd))

        
        attitude_msg = Vector3Stamped()
        attitude_msg.header.stamp = self.get_clock().now().to_msg()
        attitude_msg.header.frame_id = 'body'
        attitude_msg.vector.x = roll_cmd     # desired roll  [rad]
        attitude_msg.vector.y = pitch_cmd    # desired pitch [rad]
        attitude_msg.vector.z = self.yaw_des  # desired yaw is always 0
        self.attitude_pub.publish(attitude_msg)

        thrust_msg = Float64()
        tilt_factor=math.cos(pitch_cmd)*math.cos(roll_cmd)
        thrust_msg.data = self.mass*(az_des+self.gravity)/tilt_factor
        self.thrust_pub.publish(thrust_msg)


def main(args=None):
    rclpy.init(args=args)
    node = OuterPIDNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
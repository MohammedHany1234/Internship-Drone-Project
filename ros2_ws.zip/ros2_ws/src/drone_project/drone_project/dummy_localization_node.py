#!/usr/bin/env python3
"""
Dummy localization node.

Stands in for a real state estimator + inner attitude controller + vehicle
dynamics, so the outer position loop can be tested closed-loop without a
full simulator. Subscribes to the desired roll/pitch (and a climb-rate
command) from the outer PID node and integrates a simplified point-mass
model to produce a "current position."

Model (small-angle style, but using tan() so larger tilt angles still
behave reasonably):
    ax =  g * tan(pitch) - drag * vx
    ay = -g * tan(roll)  - drag * vy
    vz -> first-order lag toward the commanded climb rate

This implicitly assumes the inner attitude loop tracks roll/pitch commands
instantly and perfectly -- reasonable for testing/tuning the outer loop in
isolation, but NOT a substitute for a real flight dynamics model.
"""
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Vector3Stamped
from std_msgs.msg import Float64


class DummyLocalizationNode(Node):
    def __init__(self):
        super().__init__('dummy_localization_node')

        self.mass=1.5
        sim_rate = 100    # [Hz]
        self.dt = 1.0 / sim_rate
        self.g = 9.81
        self.drag = 0.5

        x0, y0, z0 = 0.0,0.0,0.0
        self.x, self.y, self.z = x0, y0, z0
        self.vx, self.vy, self.vz = 0.0, 0.0, 0.0

        self.roll = 0.0
        self.pitch = 0.0
        self.thrust = self.mass * self.g

        self.position_pub = self.create_publisher(
            PoseStamped, '/localization/current_position', 10)
        self.create_subscription(
            Vector3Stamped, '/control/desired_attitude', self.attitude_cb, 10)
        self.create_subscription(
            Float64, '/control/desired_thrust', self.thrust_cb, 10)

        self.timer = self.create_timer(self.dt, self.step)

        self.get_logger().info(
            f'Dummy localization node started at {sim_rate} Hz, '
            f'initial position={(self.x, self.y, self.z)}.')

    def attitude_cb(self, msg: Vector3Stamped):
        self.roll = msg.vector.x
        self.pitch = msg.vector.y
        # yaw (msg.vector.z) is ignored -- always assumed 0 in this model

    def thrust_cb(self, msg: Float64):
        self.thrust = msg.data

    def step(self):
        ax = (1/self.mass)*(self.thrust * math.cos(self.roll) * math.sin(self.pitch) - self.drag * self.vx)
        ay = (1/self.mass)*(-self.thrust * math.sin(self.roll) - self.drag * self.vy)
        az= (1/self.mass)*(self.thrust * math.cos(self.roll) * math.cos(self.pitch) - self.drag * self.vz )-self.g

        self.vx += ax * self.dt
        self.vy += ay * self.dt
        self.vz += az * self.dt

        self.x += self.vx * self.dt
        self.y += self.vy * self.dt
        self.z += self.vz * self.dt

        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'world'
        msg.pose.position.x = self.x
        msg.pose.position.y = self.y
        msg.pose.position.z = self.z
        msg.pose.orientation.w = 1.0  # yaw = 0
        self.position_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = DummyLocalizationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
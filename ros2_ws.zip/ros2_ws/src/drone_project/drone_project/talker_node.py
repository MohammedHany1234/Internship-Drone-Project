import rclpy
import socket
from rclpy.node import Node
from std_msgs.msg import String

class TalkerNode(Node):
    def __init__(self):
        super().__init__('talker_node')
        self.publisher_ = self.create_publisher(String, 'drone_status', 10)
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.count = 0
        self.ESP32_IP = "192.168.4.1"   # fixed AP IP, always the same
        self.UDP_PORT = 4210
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def timer_callback(self):
        msg = String()
        msg.data = f'Drone status update #{self.count}'
        self.sock.sendto(msg.data.encode(), (self.ESP32_IP, self.UDP_PORT))
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: "{msg.data}"')
        self.count += 1
        self.sock.close()

def main(args=None):
    rclpy.init(args=args)
    node = TalkerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='drone_project',
            executable='talker_node',
            name='talker_node',
            output='screen'
        ),
        Node(
            package='drone_project',
            executable='listener_node',
            name='listener_node',
            output='screen'
        ),
    ])
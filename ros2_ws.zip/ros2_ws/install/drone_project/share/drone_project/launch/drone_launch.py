from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='drone_project',
            executable='talker_node',
            name='talker_node',
            output='screen'
        ),
        Node(
            package='drone_project',
            executable='listener_node',
            name='listener_node',
            output='screen'
        ),
        Node(
            package='drone_project',
            executable='planning_node',
            name='planning_node',
            output='screen'
        ),
        Node(
            package='drone_project',
            executable='outer_pid_node',
            name='outer_pid_node',
            output='screen'
        ),
        Node(
            package='drone_project',
            executable='dummy_localization_node',
            name='dummy_localization_node',
            output='screen'
        ),
        Node(
            package='drone_project',
            executable='trajectory_plotter_node',
            name='trajectory_plotter_node',
            output='screen'
        ),
    ])